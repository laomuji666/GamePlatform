#include "account.h"
#include "ui_account.h"

Account::Account(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::account)
{
    ui->setupUi(this);
    setWindowTitle("老母鸡对战平台-account");
    setFixedSize(width(),height());
    readConfig();
    ui->label_picture->installEventFilter(this);
    ui->pushButton_register->installEventFilter(this);
    ui->pushButton_login->installEventFilter(this);
    getCodeKey();
}

Account::~Account()
{
    delete ui;
}

void Account::writeConfig()
{
    QSettings settings(configPath,QSettings::IniFormat);
    if(ui->checkBox_remember->isChecked()){
        settings.setValue("username",ui->lineEdit_username->text());
        settings.setValue("password",ui->lineEdit_password->text());
    }else{
        settings.clear();
    }
    settings.setValue("remember",ui->checkBox_remember->isChecked());

}

void Account::readConfig()
{
    QSettings settings(configPath,QSettings::IniFormat);
    if(settings.value("remember").toBool()==true){
        ui->lineEdit_username->setText(settings.value("username").toString());
        ui->lineEdit_password->setText(settings.value("password").toString());
        ui->checkBox_remember->setChecked(true);
    }
}

void Account::getCodeKey()
{
    if(codeKeyManager==nullptr){
        ui->lineEdit_code->setText("");
        codeKeyManager=HttpRequest::getRequest("/account/code/key",this,SLOT(getCodeKeySlot(QNetworkReply*)));
    }
}

void Account::getCodeKeySlot(QNetworkReply*reply)
{
    codeKey=reply->readAll();
    reply->deleteLater();
    codeKeyManager->deleteLater();
    codeKeyManager=nullptr;
    getCodePicture();
}

void Account::getCodePicture()
{
    if(codePictureManager==nullptr){
        codePictureManager=HttpRequest::getRequest("/account/code/picture?codeKey="+codeKey,this,SLOT(getCodePictureSlot(QNetworkReply*)));
    }
}

void Account::getCodePictureSlot(QNetworkReply*reply)
{
    pixmap.loadFromData(reply->readAll());
    pixmap.scaled(ui->label_picture->size(), Qt::KeepAspectRatio);
    ui->label_picture->setScaledContents(true);
    ui->label_picture->setPixmap(pixmap);
    reply->deleteLater();
    codePictureManager->deleteLater();
    codePictureManager=nullptr;
}

void Account::registerAccount()
{
    if(registerManager==nullptr){
        QString data="username="+ui->lineEdit_username->text()+"&password="+ui->lineEdit_password->text()+"&codeKey="+codeKey+"&codeStr="+ui->lineEdit_code->text();
        registerManager=HttpRequest::postRequest("/account/register",data,this,SLOT(registerAccountSlot(QNetworkReply*)));
    }
}
void Account::registerAccountSlot(QNetworkReply*reply)
{
    QByteArray bytes=reply->readAll();
    QString id=HttpRequest::getJsonValue(bytes,"id");
    QString str=HttpRequest::getJsonValue(bytes,"str");
    QMessageBox::information(this,"注册代码:"+id,str);
    reply->deleteLater();
    registerManager->deleteLater();
    registerManager=nullptr;
    if(id=="0")writeConfig();//如果注册成功,则检查是否需要保存账户
    getCodeKey();//刷新验证码
}

void Account::loginAccount()
{
    if(loginManager==nullptr){
        QString data="username="+ui->lineEdit_username->text()+"&password="+ui->lineEdit_password->text()+"&codeKey="+codeKey+"&codeStr="+ui->lineEdit_code->text();
        loginManager=HttpRequest::postRequest("/account/login",data,this,SLOT(loginAccountSlot(QNetworkReply*)));
    }
}

void Account::loginAccountSlot(QNetworkReply*reply)
{
    QByteArray bytes=reply->readAll();
    QString id=HttpRequest::getJsonValue(bytes,"id");
    QString str=HttpRequest::getJsonValue(bytes,"str");
    if(id=="0"){
        writeConfig();
        //登陆成功,加载到新的页面
        Lobby *lobby=new Lobby(ui->lineEdit_username->text(),str);
        lobby->show();
        this->close();//不能关闭,关闭会偶尔会卡死...
    }else{
       QMessageBox::information(this,"登陆代码:"+id,str);
       getCodeKey();
    }
    reply->deleteLater();
    loginManager->deleteLater();
    loginManager=nullptr;
}


//当记住账号密码被改变时,检查是否需要修改配置文件
void Account::on_checkBox_remember_stateChanged(int arg1)
{
    writeConfig();
}

bool Account::eventFilter(QObject *watched, QEvent *event)
{
    if(event->type()==QEvent::MouseButtonPress)
    {
        if(watched==ui->pushButton_login)loginAccount();
        if(watched==ui->pushButton_register)registerAccount();
        if(watched==ui->label_picture)getCodeKey();
    }
    return QWidget::eventFilter(watched,event);
}

void Account::on_lineEdit_code_editingFinished()
{
    loginAccount();
}
