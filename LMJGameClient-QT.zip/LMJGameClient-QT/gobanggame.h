#ifndef GOBANGGAME_H
#define GOBANGGAME_H

#include <QMainWindow>
#include <QPainter>
#include <QMouseEvent>
#include <QTimer>
#include "homechoose.h"
#include "httprequest.h"
namespace Ui {
class GobangGame;
}

class GobangGame : public QMainWindow
{
    Q_OBJECT

public:
    explicit GobangGame(QString username,QString onlineKey,QWidget *parent = nullptr);
    ~GobangGame();
protected:
    void closeEvent(QCloseEvent *event);
    void paintEvent(QPaintEvent *event);
    QWidget* parent;

//请求管理器
private:
    QNetworkAccessManager*setReadyManager=nullptr;
    QNetworkAccessManager*getReadyManager=nullptr;
    QNetworkAccessManager*getGameDataManager=nullptr;
    QNetworkAccessManager*setGameDataManager=nullptr;
    QNetworkAccessManager*setGameOverManager=nullptr;

//槽函数
private slots:
    void setReady();
    void getReady();
    void getGameData();
    void setGameOver();
    void setGameData(QString data);
    void setReadySlot(QNetworkReply*);
    void getReadySlot(QNetworkReply*);
    void getGameDataSlot(QNetworkReply*);
    void setGameDataSlot(QNetworkReply*);
    void setGameOverSlot(QNetworkReply*);
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();

private:
    Ui::GobangGame *ui;

    QString username,onlineKey;
    QString isReady;
    QString whoPosition;
    QTimer*readyTimer;
    QTimer*gameDataTimer;
private:
    //棋盘大小为15*15,每格大小为40*40
    int boardXSize=15,boardYSize=15;
    int piecesSize=40;
    int board[15][15];
    void replay();
    void drawBoard(QPainter*paint);
    void drawPieces(QPainter*paint);
    void mouseReleaseEvent(QMouseEvent *event);
};

#endif // GOBANGGAME_H
