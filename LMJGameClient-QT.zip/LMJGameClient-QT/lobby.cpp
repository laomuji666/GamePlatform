#include "lobby.h"
#include "ui_lobby.h"

Lobby::Lobby(QString username,QString onlineKey,QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Lobby)
{
    ui->setupUi(this);
    setFixedSize(width(),height());
    setWindowTitle("选择游戏大厅 - "+username);
    this->username=username;
    this->onlineKey=onlineKey;
    updateTime();//先更新一下时间,防止断线重连后过长未更新时间
    QTimer*updateTimer=new QTimer(this);
    connect(updateTimer,&QTimer::timeout,[&](){updateTime();});
    updateTimer->start(5000);
    online();
}

Lobby::~Lobby()
{
    delete ui;
}

//更新用户在线时间
void Lobby::updateTime()
{
    if(updateTimeManager==nullptr){
        updateTimeManager=HttpRequest::postRequest("/account/update","username="+username+"&onlineKey="+onlineKey,this,SLOT(updateTimeSlot(QNetworkReply*)));
    }
}

void Lobby::updateTimeSlot(QNetworkReply*reply)
{
    reply->deleteLater();
    updateTimeManager->deleteLater();
    updateTimeManager=nullptr;
}

//获取在线状态
void Lobby::online()
{
    if(onlineManager==nullptr){
        onlineManager=HttpRequest::postRequest("/account/online","username="+username+"&onlineKey="+onlineKey,this,SLOT(onlineSlot(QNetworkReply*)));
    }
}

void Lobby::onlineSlot(QNetworkReply*reply)
{
    QByteArray bytes=reply->readAll();
    ui->textEdit_text->append(bytes);
    QString id =HttpRequest::getJsonValue(bytes,"id");
    if(id=="1")joinChineseChess();
    if(id=="2")joinGobang();

    reply->deleteLater();
    onlineManager->deleteLater();
    onlineManager=nullptr;
}

void Lobby::offline()
{
    if(offlineManager==nullptr){
        offlineManager=HttpRequest::postRequest("/account/offline","username="+username+"&onlineKey="+onlineKey,this,SLOT(offlineSlot(QNetworkReply*)));
    }
}

void Lobby::offlineSlot(QNetworkReply*reply)
{
    QByteArray bytes=reply->readAll();
    ui->textEdit_text->append(bytes);
    reply->deleteLater();
    offlineManager->deleteLater();
    offlineManager=nullptr;
    canClose=true;
    close();
}



void Lobby::joinChineseChess()
{
    if(joinChineseChessManager==nullptr){
        joinChineseChessManager=HttpRequest::postRequest("/ChineseChess/join","username="+username+"&onlineKey="+onlineKey,this,SLOT(joinChineseChessSlot(QNetworkReply*)));
    }
}

void Lobby::joinChineseChessSlot(QNetworkReply*reply)
{
    QByteArray bytes =reply->readAll();
    QString id = HttpRequest::getJsonValue(bytes,"id");
    if(id=="0"||id=="1"){
        HomeChoose * lobby= new HomeChoose(username,onlineKey,"/ChineseChess",this);
        lobby->showWindow();
        this->hide();
    }
    ui->textEdit_text->append("象棋:"+bytes);
    reply->deleteLater();
    joinChineseChessManager->deleteLater();
    joinChineseChessManager=nullptr;
}

void Lobby::exitChineseChess()
{
    if(exitChineseChessManager==nullptr){
        exitChineseChessManager=HttpRequest::postRequest("/ChineseChess/exit","username="+username+"&onlineKey="+onlineKey,this,SLOT(exitChineseChessSlot(QNetworkReply*)));
    }
}

void Lobby::exitChineseChessSlot(QNetworkReply*reply)
{
    ui->textEdit_text->append("象棋:"+reply->readAll());
    reply->deleteLater();
    exitChineseChessManager->deleteLater();
    exitChineseChessManager=nullptr;
}



void Lobby::joinGobang()
{
    if(joinGobangManager==nullptr){
        joinGobangManager=HttpRequest::postRequest("/Gobang/join","username="+username+"&onlineKey="+onlineKey,this,SLOT(joinGobangSlot(QNetworkReply*)));
    }
}

void Lobby::joinGobangSlot(QNetworkReply*reply)
{
    QByteArray bytes =reply->readAll();
    QString id = HttpRequest::getJsonValue(bytes,"id");
    if(id=="0"||id=="1"){
        HomeChoose * lobby= new HomeChoose(username,onlineKey,"/Gobang",this);
        lobby->showWindow();
        this->hide();
    }
    ui->textEdit_text->append("五子棋:"+bytes);
    reply->deleteLater();
    joinGobangManager->deleteLater();
    joinGobangManager=nullptr;
}

void Lobby::exitGobang()
{
    if(exitGobangManager==nullptr){
        exitGobangManager=HttpRequest::postRequest("/Gobang/exit","username="+username+"&onlineKey="+onlineKey,this,SLOT(exitGobangSlot(QNetworkReply*)));
    }
}

void Lobby::exitGobangSlot(QNetworkReply*reply)
{
    ui->textEdit_text->append("五子棋:"+reply->readAll());
    reply->deleteLater();
    exitGobangManager->deleteLater();
    exitGobangManager=nullptr;
}

void Lobby::closeEvent(QCloseEvent *event)
{
    //退出时,发送退出请求
    offline();
    if(canClose){
         event->accept();
    }else{
         event->ignore();
    }
    //QWidget::closeEvent(event);
}

void Lobby::on_pushButton_ChineseChess_clicked()
{
    joinChineseChess();
}

void Lobby::on_pushButton_ChineseChess_exit_clicked()
{
    exitChineseChess();
}

void Lobby::on_pushButton_Gobang_clicked()
{
    joinGobang();
}

void Lobby::on_pushButton_Gobang_exit_clicked()
{
    exitGobang();
}
