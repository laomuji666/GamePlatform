#include "gobanggame.h"
#include "ui_gobanggame.h"

GobangGame::GobangGame(QString username,QString onlineKey,QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::GobangGame)
{

    ui->setupUi(this);
    setWindowTitle(username);
    this->parent=parent;
    this->username=username;
    this->onlineKey=onlineKey;
    ((HomeChoose*)parent)->hideWindow();
    setFixedSize(width(),height());
    readyTimer=new QTimer();
    connect(readyTimer,SIGNAL(timeout()),this,SLOT(getReady()));
    readyTimer->start(1000);
    gameDataTimer=new QTimer();
    connect(gameDataTimer,SIGNAL(timeout()),this,SLOT(getGameData()));
    gameDataTimer->start(1000);
    replay();
}
void GobangGame::replay(){
    for (int i=0;i<15;i++) {
        for (int j=0;j<15;j++) {
            board[i][j]=0;
        }
    }
}

GobangGame::~GobangGame()
{
    delete ui;
}

void GobangGame::paintEvent(QPaintEvent *event){
    QPainter *paint=new QPainter(this);
    //画笔设置反锯齿
    paint->setRenderHint(QPainter::Antialiasing);
    //画棋盘
    drawBoard(paint);
    //画棋子
    drawPieces(paint);
    //结束绘制
    paint->end();
}
void GobangGame::drawBoard(QPainter *paint){
    //设置黑色画笔,透明画刷
    paint->setPen(Qt::black);
    paint->setBrush(Qt::transparent);
    //画棋盘,由于棋子下在两条线的交点上,15条线有14个格子,所以要-1
    for (int i=0;i<boardXSize-1;i++) {
        for (int j=0;j<boardYSize-1;j++) {
            paint->drawRect((i+1)*piecesSize,(j+1)*piecesSize,piecesSize,piecesSize);
        }
    }
}

//画棋子
void GobangGame::drawPieces(QPainter *paint){
    for (int i=0;i<boardXSize;i++) {
        for (int j=0;j<boardYSize;j++) {
            int color=board[i][j];
            if(color==1){
                paint->setBrush(Qt::black);
                paint->drawRoundRect((i+1)*piecesSize-piecesSize/2,(j+1)*piecesSize-piecesSize/2,piecesSize,piecesSize,90,90);
            }else if(color==2){
                paint->setBrush(Qt::white);
                paint->drawRoundRect((i+1)*piecesSize-piecesSize/2,(j+1)*piecesSize-piecesSize/2,piecesSize,piecesSize,90,90);
            }
        }
    }
}

//鼠标点击
void GobangGame::mouseReleaseEvent(QMouseEvent *event){
    //将x,y坐标转换为棋子的位置
    int x=event->x()/piecesSize-1;
    int y=event->y()/piecesSize-1;
    //剩余位置超出棋子一半大小则+1 属于下一个棋子
    if(event->x()%piecesSize>piecesSize/2)x+=1;
    if(event->y()%piecesSize>piecesSize/2)y+=1;
    if(x>15||y>15 ||x<0 ||y<0)return;
    setGameData(QString::number(x)+","+QString::number(y));
}


void GobangGame::closeEvent(QCloseEvent *event)
{
    ((HomeChoose*)parent)->showWindow();
    ((HomeChoose*)parent)->exitHome();
    readyTimer->stop();
    gameDataTimer->stop();
    QWidget::closeEvent(event);
}



void GobangGame::setReady()
{
    if(setReadyManager==nullptr){
        setReadyManager=HttpRequest::postRequest("/Gobang/home/ready/set","username="+username+"&onlineKey="+onlineKey+"&isReady="+isReady,this,SLOT(setReadySlot(QNetworkReply*)));
    }
}

void GobangGame::setReadySlot(QNetworkReply*reply)
{
    reply->deleteLater();
    setReadyManager->deleteLater();
    setReadyManager=nullptr;
}

void GobangGame::getReady()
{
    if(getReadyManager==nullptr){
        getReadyManager=HttpRequest::postRequest("/Gobang/home/ready/get","username="+username+"&onlineKey="+onlineKey,this,SLOT(getReadySlot(QNetworkReply*)));
    }
}

void GobangGame::getReadySlot(QNetworkReply*reply)
{
    QByteArray bytes=reply->readAll();
    QString id =HttpRequest::getJsonValue(bytes,"id");
    if(id=="0")ui->pushButton_2->setEnabled(false);
    if(id=="1")ui->pushButton_2->setEnabled(true);
    QString str = HttpRequest::getJsonValue(bytes,"str");
    ui->label->setText(str);
    reply->deleteLater();
    getReadyManager->deleteLater();
    getReadyManager=nullptr;
}

void GobangGame::getGameData()
{
    if(getGameDataManager==nullptr){
        getGameDataManager=HttpRequest::postRequest("/Gobang/home/game/data/get","username="+username+"&onlineKey="+onlineKey,this,SLOT(getGameDataSlot(QNetworkReply*)));
    }
}

void GobangGame::getGameDataSlot(QNetworkReply*reply)
{
    QByteArray bytes=reply->readAll();
    QString id=HttpRequest::getJsonValue(bytes,"id");
    if(id=="0"){
        QString str=HttpRequest::getJsonValue(bytes,"str");
        QStringList list=str.split(":",QString::SkipEmptyParts);
        if(list.size()==3){
            QString whoChess=list[0];
            QString winner=list[1];
            ui->label_2->setText("轮到:"+whoChess);
            if(winner!="0"){
                if(winner=="1")ui->label_2->setText("黑棋胜利!");
                if(winner=="2")ui->label_2->setText("白棋胜利!");
                setGameOver();
            }
            QString boardStr=list[2];
            QStringList list1=boardStr.split(",",QString::SkipEmptyParts);
            for (int i=0;i<list1.size();i++) {
                QStringList list2=list1[i].split("-",QString::SkipEmptyParts);
                for(int j=0;j<list2.size();j++){
                    board[i][j]=list2[j].toInt();
                }
            }
        }
    }
    ui->label_3->setText(bytes);
    reply->deleteLater();
    getGameDataManager->deleteLater();
    getGameDataManager=nullptr;
    repaint();
}

void GobangGame::setGameData(QString data)
{
    if(setGameDataManager==nullptr){
        setGameDataManager=HttpRequest::postRequest("/Gobang/home/game/data/set","username="+username+"&onlineKey="+onlineKey+"&data="+data,this,SLOT(setGameDataSlot(QNetworkReply*)));
    }
}

void GobangGame::setGameDataSlot(QNetworkReply*reply)
{
    ui->label_4->setText(reply->readAll());
    reply->deleteLater();
    setGameDataManager->deleteLater();
    setGameDataManager=nullptr;
    getGameData();
}

void GobangGame::setGameOver()
{
    if(setGameOverManager==nullptr){
        setGameOverManager=HttpRequest::postRequest("/Gobang/home/game/over","username="+username+"&onlineKey="+onlineKey,this,SLOT(setGameOverSlot(QNetworkReply*)));
    }

}

void GobangGame::setGameOverSlot(QNetworkReply*reply)
{
    ui->label_5->setText(reply->readAll());
    isReady="no";
    reply->deleteLater();
    setGameOverManager->deleteLater();
    setGameOverManager=nullptr;
}

void GobangGame::on_pushButton_2_clicked()
{
    if(isReady=="yes"){
        isReady="no";
    }else{
        isReady="yes";
    }
    replay();
    setReady();
}

void GobangGame::on_pushButton_3_clicked()
{
    setGameData(ui->lineEdit->text());
}

void GobangGame::on_pushButton_4_clicked()
{
    setGameOver();
}
