/*
    和账号有关的请求
 */

package com.example.lmjgameclient20.account

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.example.lmjgameclient20.Url
import okhttp3.*


object AccountModel {

    //用于获取验证码
    private var codeOkHttpClient = OkHttpClient()

    //用于注册或登陆
    private var accountOkHttpClient =OkHttpClient()

    //获取通知的HttpClient
    private val notifyHttpClient = OkHttpClient()

    //记录codeKey
    private var codeKey = ""

    //载入codeKey
    fun loadCodeCodeKey(){
        val url = Url.ACCOUNT_CODE_KEY
        val request = Request.Builder().url(url).get().build()
        val execute = codeOkHttpClient.newCall(request).execute()
        val body=execute.body ?:return
        codeKey =String(body.bytes())
    }

    //获取验证码图片,成功返回图片,失败返回null
    fun loadCodePicture(): Bitmap? {
        val url=Url.ACCOUNT_CODE_PICTURE+"?codeKey="+ codeKey
        val request = Request.Builder().url(url).get().build()
        val execute = codeOkHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return BitmapFactory.decodeStream(body.byteStream())
    }

    //登陆,请求发送成功返回结果,请求失败返回null
    fun login(username:String,password:String,code:String):String?{
        val url=Url.ACCOUNT_LOGIN
        val formBody = FormBody.Builder()
        formBody.add("username",username)
        formBody.add("password",password)
        formBody.add("codeKey", codeKey)
        formBody.add("codeStr",code)
        val request = Request.Builder().url(url).post(formBody.build()).build()
        val execute = accountOkHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return String(body.bytes())
    }

    //注册,请求发送成功返回结果,请求失败返回null
    fun register(username:String,password:String,code:String):String?{
        val url=Url.ACCOUNT_REGISTER
        val formBody = FormBody.Builder()
        formBody.add("username",username)
        formBody.add("password",password)
        formBody.add("codeKey", codeKey)
        formBody.add("codeStr",code)
        val request = Request.Builder().url(url).post(formBody.build()).build()
        val execute = accountOkHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return String(body.bytes())
    }

    //请求获取通知
    fun loadNotify():String?{
        val url = Url.NOTIFY_GET
        val request = Request.Builder().url(url).get().build()
        val execute = notifyHttpClient.newCall(request).execute()
        val body=execute.body ?:return null
        return String(body.bytes())
    }
}