package com.example.lmjgameclient20.account

import android.graphics.Bitmap
import com.example.lmjgameclient20.lobby.LobbyModel

object AccountControl {

    //刷新CodeKey,获取新的验证码图片
    fun getCodeImage():Bitmap?{
        AccountModel.loadCodeCodeKey()
        return AccountModel.loadCodePicture()
    }

    //登陆
    fun login(username:String,password:String,code:String):String?{
        return AccountModel.login(username, password, code)
    }

    //注册
    fun register(username:String,password:String,code:String):String?{
        return AccountModel.register(username, password, code)
    }

    //读取通知
    fun loadNotify():String?{
        return AccountModel.loadNotify()
    }

}