/*
    功能:注册,登陆,获取通知
 */

package com.example.lmjgameclient20.account

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.lmjgameclient20.OnlineData
import com.example.lmjgameclient20.R
import com.example.lmjgameclient20.lobby.LobbyActivity
import kotlinx.android.synthetic.main.activity_account.*

import org.json.JSONObject

class AccountActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account)
        initWidget()
        updateCodeImage()
    }

    //初始化组件
    private fun initWidget(){

        //点击图片,刷新验证码
        activity_login_ImageView_codePicture.setOnClickListener {
            updateCodeImage()
        }

        //点击登陆按钮
        activity_login_Button_login.setOnClickListener {
            val username=activity_login_EditText_username.text.toString()
            val password=activity_login_EditText_password.text.toString()
            val code=activity_login_EditText_code.text.toString()
            if (username.isEmpty() ||password.isEmpty()){
                Toast.makeText(this, "账号密码不能为空", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            login(username, password, code)
        }

        //点击注册按钮
        activity_login_Button_register.setOnClickListener {
            val username=activity_login_EditText_username.text.toString()
            val password=activity_login_EditText_password.text.toString()
            val code=activity_login_EditText_code.text.toString()
            if (username.isEmpty() ||password.isEmpty()||code.isEmpty()){
                Toast.makeText(this, "注册资料不完整", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            register(username, password, code)
        }

        //当记住密码被点击时
        activity_login_CheckBox_remember.setOnClickListener {
            writeUser()
        }

        //读取保存的账号密码
        readUser()

        //获取通知
        loadNotify()
    }

    //更新验证码图片
    private fun updateCodeImage(){
        Thread{
            val bitmap= AccountControl.getCodeImage() ?: return@Thread
            runOnUiThread {
                activity_login_ImageView_codePicture.setImageBitmap(bitmap)
            }
        }.start()
    }

    //登陆
    private fun login(username:String,password:String,code:String){
        Thread{
            val res= AccountControl.login(username, password, code) ?: return@Thread
            val obj =JSONObject(res)
            val id =obj.getString("id")
            val str = obj.getString("str")
            if(id == "0"){
                //登陆成功
                //更新在线数据
                OnlineData.username=username
                OnlineData.onlineKey=str
                //启动大厅
                startActivity(Intent(this, LobbyActivity::class.java))
                //如果选中记住密码,在登陆成功时保存账号密码
                writeUser()
                //销毁自身
                finish()
            }else{
                //登陆失败
                runOnUiThread{
                    //刷新验证码
                    updateCodeImage()
                    //提示登陆失败原因
                    Toast.makeText(this,str , Toast.LENGTH_SHORT).show()
                    //清理验证码
                    activity_login_EditText_code.setText("")
                }
            }

        }.start()
    }

    //注册
    private fun register(username:String,password:String,code:String){
        Thread{
            val res= AccountControl.register(username, password, code) ?: return@Thread
            val obj =JSONObject(res)
            //无论注册成功还是失败都会执行
            runOnUiThread{
                //刷新验证码
                updateCodeImage()
                //提示登陆失败原因
                Toast.makeText(this, obj.getString("str"), Toast.LENGTH_LONG).show()
                //清理验证码
                activity_login_EditText_code.setText("")
            }
        }.start()
    }

    //读取账号密码
    private fun readUser(){
        val sharedPreferences = getSharedPreferences("user", Context.MODE_PRIVATE)
        //如果选择了记住密码,就读取账号密码
        if(sharedPreferences.getBoolean("remember", false)){
            val username = sharedPreferences.getString("username","")
            val password = sharedPreferences.getString("password","")
            activity_login_EditText_username.setText(username)
            activity_login_EditText_password.setText(password)
            activity_login_CheckBox_remember.isChecked=true
        }
    }

    //保存账号密码
    private fun writeUser(){
        val edit = getSharedPreferences("user", Context.MODE_PRIVATE).edit()
        val remember=activity_login_CheckBox_remember.isChecked
        if(remember){
            edit.putBoolean("remember",remember)
            edit.putString("username",activity_login_EditText_username.text.toString())
            edit.putString("password",activity_login_EditText_password.text.toString())
        }else{
            edit.clear()
        }
        edit.commit()
    }

    //读取通知
    private fun loadNotify(){
        Thread{
            val data= AccountControl.loadNotify()?: return@Thread
            runOnUiThread {
                activity_account_TextView_notify.append(data+"\n")
            }
        }.start()
    }
}