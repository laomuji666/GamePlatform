/*
    功能:加入游戏大厅,断线重连,更新在线时间,加入游戏大厅,退出游戏大厅
    备注:该活动请勿销毁,销毁时会停止更新在线时间
 */

package com.example.lmjgameclient20.lobby

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.KeyEvent
import android.widget.Toast
import com.example.lmjgameclient20.R
import com.example.lmjgameclient20.Url
import com.example.lmjgameclient20.choose.ChooseActivity
import com.example.lmjgameclient20.choose.ChooseControl
import kotlinx.android.synthetic.main.activity_lobby.*
import org.json.JSONObject

class LobbyActivity : AppCompatActivity() {

    companion object{
        //用于提供退出大厅回调
        lateinit var mLobbyActivity:LobbyActivity
    }

    //初始化
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lobby)
        mLobbyActivity=this
        initWidget()
    }

    //退出时调用手动离线
    override fun onDestroy() {
        loadOffline()
        super.onDestroy()
    }

    //两秒内按下两次返回键退出
    private var exitTime:Long = 0
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if((System.currentTimeMillis()-exitTime) > 2000){
            exitTime = System.currentTimeMillis()
            Toast.makeText(this, "再按一次退出程序", Toast.LENGTH_SHORT).show();
        } else {
            return super.onKeyDown(keyCode, event);
        }
        return false;
    }

    //初始化控件
    private fun initWidget(){
        loadOnline()
        updateTime(5000)

        activity_lobby_Button_chineseChess.setOnClickListener {
            joinLobby(Url.LOBBY_CHINESECHESS)
        }

        activity_lobby_Button_gobang.setOnClickListener {
            joinLobby(Url.LOBBY_GOBANG)
        }
    }

    //获取在线状态,是正常登陆还是断线重连,重连就进入对应的大厅
    private fun loadOnline(){
        Thread{
            val data=LobbyControl.loadOnline()?: return@Thread
            val obj = JSONObject(data)
            val id = obj.getString("id")
            val str= obj.getString("str")
            runOnUiThread {
                when(id){
                    Url.LOBBY_GOBANG_ID->joinLobby(Url.LOBBY_GOBANG)
                    Url.LOBBY_CHINESECHESS_ID->joinLobby(Url.LOBBY_CHINESECHESS)
                }
                activity_lobby_TextView_text.append("$str\n")
            }
        }.start()
    }

    //手动离线
    private fun loadOffline(){
        Thread{
            LobbyControl.loadOffline()
        }.start()
    }

    //更新在线时间,循环更新,直到程序退出
    private fun updateTime(millis:Long){
        Thread{
            while (!isDestroyed){
                LobbyControl.updateTime()
                Thread.sleep(millis)
            }
        }.start()
    }

    //加入游戏大厅
    private fun joinLobby(url:String){
        Url.LOBBY_URL=url
        Thread{
            val data=LobbyControl.loadJoinLobby() ?: return@Thread
            val obj=JSONObject(data)
            val id =obj.getString("id")
            val str=obj.getString("str")
            runOnUiThread {
                if(id == "0" || id == "1"){
                    //正常加入或者重连,都可以加入大厅
                    startActivity(Intent(this,ChooseActivity::class.java))
                }
                //加入失败 提示失败原因
                activity_lobby_TextView_text.append("加入大厅:$data\n")
            }
        }.start()
    }

    //退出游戏大厅
    fun loadExitLobby(){
        Thread{
            val data=LobbyControl.loadExitLobby()?:return@Thread
            runOnUiThread {
                activity_lobby_TextView_text.append("退出大厅:$data\n")
            }
        }.start()
    }
}