package com.example.lmjgameclient20

object Url {
    //根
    private const val ROOT = "http://www.laomuji666.com:8686"

    //账户
    private const val ACCOUNT = "$ROOT/account"
    const val ACCOUNT_CODE_KEY = "$ACCOUNT/code/key"
    const val ACCOUNT_CODE_PICTURE = "$ACCOUNT/code/picture"
    const val ACCOUNT_LOGIN = "$ACCOUNT/login"
    const val ACCOUNT_REGISTER = "$ACCOUNT/register"
    const val ACCOUNT_ONLINE = "$ACCOUNT/online"
    const val ACCOUNT_OFFLINE = "$ACCOUNT/offline"
    const val ACCOUNT_UPDATE = "$ACCOUNT/update"

    //通知
    private const val NOTIFY = "$ROOT/notify"
    const val NOTIFY_GET = "$NOTIFY/get"

    //游戏大厅
    const val LOBBY_CHINESECHESS = "$ROOT/ChineseChess"
    const val LOBBY_CHINESECHESS_ID = "1"
    const val LOBBY_GOBANG = "$ROOT/Gobang"
    const val LOBBY_GOBANG_ID = "2"
    var LOBBY_URL = ""
    val LOBBY_JOIN get() = "$LOBBY_URL/join"
    val LOBBY_EXIT get() = "$LOBBY_URL/exit"
    val LOBBY_HOME_DATA get() = "$LOBBY_URL/home/data"
    val LOBBY_HOME_JOIN get() = "$LOBBY_URL/home/join"
    val LOBBY_HOME_EXIT get() = "$LOBBY_URL/home/exit"
    //准备
    val LOBBY_HOME_READY_SET get() = "$LOBBY_URL/home/ready/set"
    val LOBBY_HOME_READY_GET get() = "$LOBBY_URL/home/ready/get"
    //游戏结束
    val LOBBY_HOME_GAMEOVER get() = "$LOBBY_URL/home/game/over"
    //中国象棋
    val CHINESE_CHESS_GAME_DATA_GET get() = "$LOBBY_URL/home/game/data/get"
    val CHINESE_CHESS_GAME_ALL_CAN_CHESS get() = "$LOBBY_URL/home/game/getAllCanChess"
    val CHINESE_CHESS_GAME_DATA_SET get() = "$LOBBY_URL/home/game/data/set"
    //五子棋
    val GOBANG_GAME_DATA_GET get() = "$LOBBY_URL/home/game/data/get"
    val GOBANG_GAME_DATA_SET get() = "$LOBBY_URL/home/game/data/set"
}