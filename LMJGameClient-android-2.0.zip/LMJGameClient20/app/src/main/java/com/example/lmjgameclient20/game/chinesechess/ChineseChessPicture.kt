package com.example.lmjgameclient20.game.chinesechess

import android.content.res.Resources
import android.graphics.*
import android.util.Log
import com.example.lmjgameclient20.OnlineData
import com.example.lmjgameclient20.R
import com.example.lmjgameclient20.choose.ChooseActivity
import kotlinx.android.synthetic.main.activity_game_chinese_chess.*
import org.json.JSONObject
import kotlin.math.log


object ChineseChessPicture {

    //绘制棋盘
    fun getChineseChessPicture(data: String, resources: Resources,allCanChess:String?=null): Bitmap {
        //棋盘
        val bitmap = getBoardPicture(resources)
        //绘制棋子
        parserBoardData(data, bitmap, resources)
        //绘制落子位置提示
        if(allCanChess!=null){
            drawAllCanChess(allCanChess, bitmap, resources)
        }
        return bitmap
    }


    //解析棋子数据并且绘制,若胜利则重置对局
    private fun parserBoardData(data: String, bitmap: Bitmap, resources: Resources) {
        val obj = JSONObject(data)
        val list = obj.getString("str").split(':')
        if (list.size != 4) return
        val boardDataW = list[3].split(',')
        if (boardDataW.size != 9) return
        //循环绘制棋子
        for (i in boardDataW.indices) {
            val boardDataH = boardDataW[i].split('-')
            if (boardDataH.size != 10) return
            for (j in boardDataH.indices) {
                drawChess(i, j, boardDataH[j], bitmap, resources)
            }
        }
        //绘制最后一个落子位置

        val lastPoint=list[0].split(',')
        if(lastPoint.size==4){
            drawChess(lastPoint[0].toInt(), lastPoint[1].toInt(), "last", bitmap, resources)
            drawChess(lastPoint[2].toInt(), lastPoint[3].toInt(), "last", bitmap, resources)
        }
        if(list[2]!="无"){
            //游戏结束
            ChooseActivity.mChooseActivity.loadGameOver()
            ChineseChess.mChineseChess.runOnUiThread {
                ChineseChess.mChineseChess.activity_game_chinese_chess_Button_ready.text="准备"
                ChineseChess.mChineseChess.activity_game_chinese_chess_TextView_ready.text="未准备"
            }
            OnlineData.isReady="no"
        }

    }

    //绘制棋盘
    private fun getBoardPicture(resources: Resources): Bitmap {
        var bitBoard = BitmapFactory.decodeResource(resources, R.drawable.board)
        return Bitmap.createBitmap(bitBoard.width, bitBoard.height, Bitmap.Config.ARGB_8888)
    }

    //在棋盘中绘制棋子
    private fun drawChess(xPoint: Int, yPoint: Int, type: String, bitBoard: Bitmap, resources: Resources) {
        var bitChess: Bitmap = when (type) {
            "help" -> BitmapFactory.decodeResource(resources, R.drawable.choose_chess)
            "last" -> BitmapFactory.decodeResource(resources, R.drawable.last_chess)

            "1" -> BitmapFactory.decodeResource(resources, R.drawable.black_ju)
            "2" -> BitmapFactory.decodeResource(resources, R.drawable.black_ma)
            "3" -> BitmapFactory.decodeResource(resources, R.drawable.black_xiang)
            "4" -> BitmapFactory.decodeResource(resources, R.drawable.black_shi)
            "5" -> BitmapFactory.decodeResource(resources, R.drawable.black_jiang)
            "6" -> BitmapFactory.decodeResource(resources, R.drawable.black_pao)
            "7" -> BitmapFactory.decodeResource(resources, R.drawable.black_zu)

            "11" -> BitmapFactory.decodeResource(resources, R.drawable.red_ju)
            "12" -> BitmapFactory.decodeResource(resources, R.drawable.red_ma)
            "13" -> BitmapFactory.decodeResource(resources, R.drawable.red_xiang)
            "14" -> BitmapFactory.decodeResource(resources, R.drawable.red_shi)
            "15" -> BitmapFactory.decodeResource(resources, R.drawable.red_shuai)
            "16" -> BitmapFactory.decodeResource(resources, R.drawable.red_pao)
            "17" -> BitmapFactory.decodeResource(resources, R.drawable.red_bing)
            else -> return
        }

        bitChess = scaleBitmap(bitChess, bitBoard.width / 9, bitBoard.height / 10)

        //获取绘制坐标
        val xChess = xPoint * bitBoard.width / 9
        val yChess = yPoint * bitBoard.height / 10
        //绘制到图片上
        val canvas: Canvas = Canvas(bitBoard)
        canvas.drawBitmap(bitChess, xChess.toFloat(), yChess.toFloat(), Paint())
        canvas.drawBitmap(bitBoard, 0f, 0f, Paint())
    }

    //绘制落子提示
    private fun drawAllCanChess(allCanChess: String, bitmap: Bitmap, resources: Resources){
        val list = allCanChess.split(',')
        for (i in list.indices){
            val point=list[i].split('-')
            if(point.size!=2)continue
            drawChess(point[0].toInt(),point[1].toInt(),"help",bitmap,resources)
        }
    }







    //缩放图片
    private fun scaleBitmap(origin: Bitmap, newWidth: Int, newHeight: Int): Bitmap {
        if (origin == null) return origin
        val height = origin.height
        val width = origin.width
        val scaleWidth = newWidth.toFloat() / width
        val scaleHeight = newHeight.toFloat() / height
        val matrix = Matrix()
        matrix.postScale(scaleWidth, scaleHeight) // 使用后乘
        val newBM = Bitmap.createBitmap(origin, 0, 0, width, height, matrix, false)
        if (!origin.isRecycled) origin.recycle()
        return newBM
    }

}