package com.example.lmjgameclient20.game.chinesechess

import com.example.lmjgameclient20.OnlineData
import com.example.lmjgameclient20.Url
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request

object ChineseChessModel {
    //用于获取游戏数据
    private val getGameDataHttpClient:OkHttpClient= OkHttpClient()
    //获取落子位置和移动棋子棋共用
    private val chessHttpClient:OkHttpClient= OkHttpClient()

    //获取游戏数据
    fun loadGetGameData():String?{
        val url = Url.CHINESE_CHESS_GAME_DATA_GET
        val formBody = FormBody.Builder()
        formBody.add("username", OnlineData.username)
        formBody.add("onlineKey", OnlineData.onlineKey)
        val request = Request.Builder().url(url).post(formBody.build()).build()
        val execute = getGameDataHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return String(body.bytes())
    }

    //获取落子位置提示
    fun loadGetAllCanChess(x:Int,y:Int):String?{
        val url = Url.CHINESE_CHESS_GAME_ALL_CAN_CHESS
        val formBody = FormBody.Builder()
        formBody.add("username", OnlineData.username)
        formBody.add("onlineKey", OnlineData.onlineKey)
        formBody.add("data", "$x,$y")
        val request = Request.Builder().url(url).post(formBody.build()).build()
        val execute = chessHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return String(body.bytes())
    }

    //移动棋子
    fun loadMoveChess(oldX:Int,oldY:Int,newX:Int,newY:Int):String?{
        val url = Url.CHINESE_CHESS_GAME_DATA_SET
        val formBody = FormBody.Builder()
        formBody.add("username", OnlineData.username)
        formBody.add("onlineKey", OnlineData.onlineKey)
        formBody.add("data", "$oldX,$oldY,$newX,$newY")
        val request = Request.Builder().url(url).post(formBody.build()).build()
        val execute = chessHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return String(body.bytes())
    }

}