package com.example.lmjgameclient20.lobby

import com.example.lmjgameclient20.OnlineData
import com.example.lmjgameclient20.Url
import com.example.lmjgameclient20.choose.ChooseModel
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request

object LobbyModel {


    //在线,离线,加入游戏大厅共用的HttpClient
    private val lineHttpClient = OkHttpClient()

    //更新在线时间使用的HttpClient
    private val updateHttpClient = OkHttpClient()

    //请求获取在线状态
    fun loadOnline():String?{
        val url = Url.ACCOUNT_ONLINE
        val formBody = FormBody.Builder()
        formBody.add("username",OnlineData.username)
        formBody.add("onlineKey",OnlineData.onlineKey)
        val request = Request.Builder().url(url).post(formBody.build()).build()
        val execute = lineHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return String(body.bytes())
    }

    //请求离线
    fun loadOffline():String?{
        val url = Url.ACCOUNT_OFFLINE
        val formBody = FormBody.Builder()
        formBody.add("username",OnlineData.username)
        formBody.add("onlineKey",OnlineData.onlineKey)
        val request = Request.Builder().url(url).post(formBody.build()).build()
        val execute = lineHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return String(body.bytes())
    }

    //更新在线状态
    fun loadUpdateTime():String?{
        val url = Url.ACCOUNT_UPDATE
        val formBody = FormBody.Builder()
        formBody.add("username",OnlineData.username)
        formBody.add("onlineKey",OnlineData.onlineKey)
        val request = Request.Builder().url(url).post(formBody.build()).build()
        val execute = updateHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return String(body.bytes())
    }

    //请求加入游戏大厅
    fun loadJoinLobby():String?{
        val url = Url.LOBBY_JOIN
        val formBody = FormBody.Builder()
        formBody.add("username",OnlineData.username)
        formBody.add("onlineKey",OnlineData.onlineKey)
        val request = Request.Builder().url(url).post(formBody.build()).build()
        val execute = lineHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return String(body.bytes())
    }

    //请求退出游戏大厅
    fun loadExitLobby():String?{
        val url = Url.LOBBY_EXIT
        val formBody = FormBody.Builder()
        formBody.add("username", OnlineData.username)
        formBody.add("onlineKey", OnlineData.onlineKey)
        val request = Request.Builder().url(url).post(formBody.build()).build()
        val execute = lineHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return String(body.bytes())
    }
}