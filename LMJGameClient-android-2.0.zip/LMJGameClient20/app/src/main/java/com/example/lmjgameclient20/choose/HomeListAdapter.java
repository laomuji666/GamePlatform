/*
    recycler view 使用kotlin麻烦一点,就直接用java了
 */
package com.example.lmjgameclient20.choose;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.lmjgameclient20.R;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.List;

public class HomeListAdapter extends RecyclerView.Adapter<HomeListAdapter.ViewHolder> {
    private final Context context;
    private final List<String> homeList;

    //构造方法,传入数据
    public HomeListAdapter(Context context,List<String> homeList) {
        this.context = context;
        this.homeList = homeList;
    }

    //返回ViewHolder
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v=LayoutInflater.from(context).inflate(R.layout.item_home,parent,false);
        return new ViewHolder(v);
    }

    //绑定视图与数据
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.setData(homeList.get(position));
    }

    //获取个数
    @Override
    public int getItemCount() {
        return homeList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        private TextView homeId,top,bottom;

        //绑定控件
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            homeId=itemView.findViewById(R.id.item_home_TextView_homeId);
            top=itemView.findViewById(R.id.item_home_TextView_top);
            bottom=itemView.findViewById(R.id.item_home_TextView_bottom);

            top.setOnClickListener((view)->{
                joinHome("top");
            });

            bottom.setOnClickListener((view)->{
                joinHome("bottom");
            });
        }

        //加入房间
        private void joinHome(String position){
            new Thread(()->{
                ChooseActivity.mChooseActivity.loadJoinHome(homeId.getText().toString(),position);
            }).start();
        }

        //设置数据
        public void setData(String data) {
            try {
                JSONObject obj = new JSONObject(data);
                homeId.setText(obj.getString("id"));
                top.setText(obj.getString("top"));
                bottom.setText(obj.getString("bottom"));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
