package com.example.lmjgameclient20.lobby

import android.util.Log

object LobbyControl {

    //获取在线信息
    fun loadOnline():String?{
        return LobbyModel.loadOnline()
    }

    //手动离线,直接打印结果
    fun loadOffline(){
        val data = LobbyModel.loadOffline()?:return
        Log.d("loadOffline", data)
    }

    //更新在线时间,不反馈,直接打印结果
    fun updateTime(){
        val data = LobbyModel.loadUpdateTime()?:return
        Log.d("updateOnline", data)
    }

    //请求加入游戏大厅,返回结果
    fun loadJoinLobby():String?{
        return LobbyModel.loadJoinLobby()
    }

    //请求退出大厅
    fun loadExitLobby():String?{
        return LobbyModel.loadExitLobby() ?:return null
    }


}