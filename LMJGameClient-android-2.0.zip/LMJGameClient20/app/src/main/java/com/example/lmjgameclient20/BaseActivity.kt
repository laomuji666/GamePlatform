/*
    程序执行前的操作将会放到这里
 */

package com.example.lmjgameclient20

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.lmjgameclient20.account.AccountActivity


class BaseActivity : AppCompatActivity() {

    //一切状态正常时,调用该函数.
    private fun start(){
        startActivity(Intent(this,
            AccountActivity::class.java))
        finish()
    }

    //初始化,被onCreate调用
    private fun initialize(){
        start()
    }





    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_base)
        initialize()
    }
}