/*
    在onStart中启动获取准备状态/获取棋盘数据
    在onStop中停止获取准备状态/获取棋盘数据
 */

package com.example.lmjgameclient20.game.gobang

import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.lmjgameclient20.R
import com.example.lmjgameclient20.choose.ChooseActivity
import kotlinx.android.synthetic.main.activity_game_gobang.*
import org.json.JSONObject


class Gobang : AppCompatActivity() {

    //循环条件
    private var needGetReady = false


    companion object{
        lateinit var mGobang:Gobang
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_gobang)
        initWidget()
        mGobang=this
    }


    private fun initWidget(){
        setReady()
        activity_game_gobang_Button_ready.setOnClickListener {
            setReady()
        }

        //隐藏顶部任务栏
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN)

        //设置棋盘点击事件
        activity_game_gobang_ImageView_board.setOnTouchListener { v, event ->
            if(event.action==MotionEvent.ACTION_UP){
                clickBoard(event)
            }
            return@setOnTouchListener true
        }
    }

    //点击棋盘 转换为坐标,并请求
    private fun clickBoard(event: MotionEvent){
        //获取点击坐标
        val boardW=activity_game_gobang_ImageView_board.width
        val boardH=activity_game_gobang_ImageView_board.height
        val chessW=boardW/15
        val chessH=boardH/15
        val chessBeginX=0
        val chessBeginY=0
        val xPoint = (event.x.toInt()-chessBeginX)/chessW
        val yPoint = (event.y.toInt()-chessBeginY)/chessH
        Thread{
            GobangModel.loadMoveChess(xPoint,yPoint)
            getGameData()

        }.start()
    }


    //设置准备状态并显示
    private fun setReady(){
        Thread{
            val data=ChooseActivity.mChooseActivity.loadSetReady()
            val id = JSONObject(data).getString("id")
            runOnUiThread {
                if(id=="1"){
                    activity_game_gobang_Button_ready.text="准备"
                    activity_game_gobang_TextView_ready.text="未准备"
                }
                if(id=="0"){
                    activity_game_gobang_Button_ready.text="取消"
                    activity_game_gobang_TextView_ready.text="已准备"
                }
            }
        }.start()
    }

    //停止时 调用ChooseActivity的退出房间
    override fun onDestroy() {
        ChooseActivity.mChooseActivity.loadExitHome()
        super.onDestroy()
    }

    //开始循环
    override fun onStart() {
        needGetReady=true
        loadGetReady(1000)
        loadGetGameData(1000)
        super.onStart()
    }

    //终止循环
    override fun onStop() {
        needGetReady=false
        super.onStop()
    }

    //循环获取准备状态
    private fun loadGetReady(millis:Long){
        Thread{
            while (needGetReady){
                val ready = ChooseActivity.mChooseActivity.loadGetReady()
                if(ready!=null){
                    runOnUiThread {
                        activity_game_gobang_TextView_text.text = ready
                    }
                }
                Thread.sleep(millis)
            }
        }.start()
    }

    //循环获取棋盘数据
    private fun loadGetGameData(millis:Long){
        Thread{
            while (needGetReady){
                getGameData()
                Thread.sleep(millis)
            }

        }.start()
    }

    //获取游戏数据并绘制
    private fun getGameData(){
        val gameData = GobangModel.loadGetGameData() ?:return
        val bitmap=GobangPicture.getGobangPicture(gameData,resources)
        runOnUiThread {
            activity_game_gobang_ImageView_board.setImageBitmap(bitmap)
        }
    }

}