package com.example.lmjgameclient20.choose

import android.util.Log
import com.example.lmjgameclient20.OnlineData
import java.util.ArrayList

object ChooseControl {

    //返回房间列表
    fun loadHomeList():List<String>{
        val list = ArrayList<String>()
        val loadHomeList = ChooseModel.loadHomeList() ?:return list
        val split = loadHomeList.split("\n")
        for (str in split) {
            if (str.isEmpty())continue
            list.add(str)
        }
        return list
    }

    //请求加入房间/重连
    fun loadJoinHome(homeId:String,position:String):String{
        OnlineData.homeId=homeId
        OnlineData.position=position
        return ChooseModel.loadJoinHome()?:return "请求失败"
    }

    //请求退出房间
    fun loadExitHome():String{
        return ChooseModel.loadExitHome()?:"请求异常"
    }

    //请求设置准备状态
    fun loadSetReady():String?{
        OnlineData.isReady=if(OnlineData.isReady=="no")"yes" else "no"
        return ChooseModel.loadSetReady()
    }

    //请求获取准备状态
    fun loadGetReady():String?{
        return ChooseModel.loadGetReady()
    }

    //请求游戏结束,只打印结果,不返回参数
    fun loadGameOver(){
        val data = ChooseModel.loadGameOver()?:return
        Log.d("loadGameOver", data)
    }
}