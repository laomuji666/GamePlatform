package com.example.lmjgameclient20.choose

import com.example.lmjgameclient20.OnlineData
import com.example.lmjgameclient20.Url
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request

object ChooseModel {
    //获取房间列表
    private val homeListHttpClient:OkHttpClient = OkHttpClient()

    //加入房间,退出房间,游戏结束共用的HttpClient
    private val chooseLobbyHttpClient:OkHttpClient = OkHttpClient()

    //设置准备状态使用的HttpClient
    private val setReadyHttpClient:OkHttpClient = OkHttpClient()

    private val getReadyHttpClient:OkHttpClient = OkHttpClient()

    //加载房间列表
    fun loadHomeList():String?{
        val url =Url.LOBBY_HOME_DATA
        val formBody = FormBody.Builder()
        formBody.add("username", OnlineData.username)
        formBody.add("onlineKey", OnlineData.onlineKey)
        val request = Request.Builder().url(url).post(formBody.build()).build()
        val execute = homeListHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return String(body.bytes())
    }

    //请求加入游戏房间
    fun loadJoinHome():String?{
        val url = Url.LOBBY_HOME_JOIN
        val formBody = FormBody.Builder()
        formBody.add("username", OnlineData.username)
        formBody.add("onlineKey", OnlineData.onlineKey)
        formBody.add("homeId", OnlineData.homeId)
        formBody.add("position", OnlineData.position)
        val request = Request.Builder().url(url).post(formBody.build()).build()
        val execute = chooseLobbyHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return String(body.bytes())
    }

    //请求退出游戏房间
    fun loadExitHome():String?{
        val url = Url.LOBBY_HOME_EXIT
        val formBody = FormBody.Builder()
        formBody.add("username", OnlineData.username)
        formBody.add("onlineKey", OnlineData.onlineKey)
        val request = Request.Builder().url(url).post(formBody.build()).build()
        val execute = chooseLobbyHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return String(body.bytes())
    }

    //设置准备状态
    fun loadSetReady():String?{
        val url = Url.LOBBY_HOME_READY_SET
        val formBody = FormBody.Builder()
        formBody.add("username", OnlineData.username)
        formBody.add("onlineKey", OnlineData.onlineKey)
        formBody.add("isReady", OnlineData.isReady)
        val request = Request.Builder().url(url).post(formBody.build()).build()
        val execute = setReadyHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return String(body.bytes())
    }

    //获取准备状态
    fun loadGetReady():String?{
        val url = Url.LOBBY_HOME_READY_GET
        val formBody = FormBody.Builder()
        formBody.add("username", OnlineData.username)
        formBody.add("onlineKey", OnlineData.onlineKey)
        val request = Request.Builder().url(url).post(formBody.build()).build()
        val execute = getReadyHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return String(body.bytes())
    }

    //发送游戏结束
    fun loadGameOver():String?{
        val url = Url.LOBBY_HOME_GAMEOVER
        val formBody = FormBody.Builder()
        formBody.add("username", OnlineData.username)
        formBody.add("onlineKey", OnlineData.onlineKey)
        val request = Request.Builder().url(url).post(formBody.build()).build()
        val execute = getReadyHttpClient.newCall(request).execute()
        val body =execute.body ?:return null
        return String(body.bytes())
    }
}