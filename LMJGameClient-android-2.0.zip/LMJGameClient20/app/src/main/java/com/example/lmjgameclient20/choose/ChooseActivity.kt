/*
    功能:房间列表,加入房间,退出房间
    当onStart时会循环请求获取房间列表
    当onStop时会停止循环请求获取房间列表
    当onDestroy时会调用LobbyActivity的退出大厅
 */

package com.example.lmjgameclient20.choose

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.lmjgameclient20.OnlineData
import com.example.lmjgameclient20.R
import com.example.lmjgameclient20.Url
import com.example.lmjgameclient20.game.chinesechess.ChineseChess
import com.example.lmjgameclient20.game.gobang.Gobang
import com.example.lmjgameclient20.lobby.LobbyActivity
import kotlinx.android.synthetic.main.activity_choose.*
import org.json.JSONObject
import java.util.ArrayList


class ChooseActivity : AppCompatActivity() {

    //用于RecyclerView的数据
    private lateinit var list:ArrayList<String>

    //适配器
    private lateinit var homeListAdapter:HomeListAdapter

    //是否获取房间列表
    private var needHomeList=false

    companion object{
        //用于提供退出房间回调
        lateinit var mChooseActivity:ChooseActivity
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose)
        mChooseActivity=this
        initWidget()
    }

    //初始化控件
    private fun initWidget(){
        val pos = Url.LOBBY_URL.lastIndexOf('/') + 1
        val text =Url.LOBBY_URL.substring(pos,Url.LOBBY_URL.length)+" 房间列表"
        activity_choose_TextView_title.text = text
        list = ArrayList<String>()
        val layoutManager=LinearLayoutManager(this)
        layoutManager.orientation=LinearLayoutManager.VERTICAL
        homeListAdapter = HomeListAdapter(this, list)
        activity_choose_RecyclerView_homes.layoutManager=layoutManager
        activity_choose_RecyclerView_homes.adapter = homeListAdapter
        Thread{loadJoinHome()}.start()
    }

    //开始时 循环获取房间列表
    override fun onStart() {
        needHomeList=true
        loadHomeList(2000)
        super.onStart()
    }

    //暂停时 终止获取房间列表
    override fun onStop() {
        needHomeList=false
        super.onStop()
    }

    //退出时 调用LobbyActivity的退出大厅
    override fun onDestroy() {
        LobbyActivity.mLobbyActivity.loadExitLobby()
        super.onDestroy()
    }

    //更新房间列表
    private fun updateHomeList(){
        val addList=ChooseControl.loadHomeList()
        if(addList.isEmpty())return
        list.clear()
        list.addAll(addList)
        runOnUiThread {
            homeListAdapter.notifyDataSetChanged()
        }
    }

    //加载列表,循环
    private fun loadHomeList(millis:Long){
        Thread{
            while (needHomeList){
                updateHomeList()
                Thread.sleep(millis)
            }
        }.start()
    }

    //加入/重连房间,进入成功打开游戏界面
    fun loadJoinHome(homeId:String="-1", position:String="top"):String{
        val data=ChooseControl.loadJoinHome(homeId,position)
        startGame(homeId,data)
        return data
    }

    //启动游戏,并且重置准备状态
    private fun startGame(homeId: String,data:String){
        val id = JSONObject(data).getString("id")
        if(id=="0"){
            OnlineData.isReady=""
            when(Url.LOBBY_URL){
                Url.LOBBY_CHINESECHESS->startActivity(Intent(this,ChineseChess::class.java))
                Url.LOBBY_GOBANG->startActivity(Intent(this, Gobang::class.java))
            }
        }
        runOnUiThread {
            activity_choose_TextView_text.text = "$homeId:$data"
            if(id == "6") activity_choose_TextView_text.text="反馈信息将会显示在这里"
        }
    }

    //退出房间
    fun loadExitHome(){
        Thread{
            val data = ChooseControl.loadExitHome()
            runOnUiThread {
                activity_choose_TextView_text.text=data
            }
        }.start()
    }

    //设置准备状态
    fun loadSetReady():String?{
        return ChooseControl.loadSetReady()
    }

    //获取准备状态
    fun loadGetReady():String?{
        return ChooseControl.loadGetReady()
    }

    //请求游戏结束,不回调
    fun loadGameOver(){
        Thread{
            ChooseControl.loadGameOver()
        }.start()
    }
}