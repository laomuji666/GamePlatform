package com.example.lmjgameclient20

//需要提交的信息,请在登陆后设置
object OnlineData {
    var username:String =""
    var onlineKey:String=""
    var homeId="-1"
    var position="top"
    var isReady=""
}