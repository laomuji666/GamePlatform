package com.example.lmjgameclient20.game.gobang

import android.content.res.Resources
import android.graphics.*
import android.util.Log
import com.example.lmjgameclient20.OnlineData
import com.example.lmjgameclient20.R
import com.example.lmjgameclient20.choose.ChooseActivity
import kotlinx.android.synthetic.main.activity_game_gobang.*
import org.json.JSONObject
import kotlin.math.log


object GobangPicture {

    //绘制棋盘
    fun getGobangPicture(data: String, resources: Resources): Bitmap {
        //棋盘
        val bitmap = getBoardPicture(resources)
        //绘制棋子
        parserBoardData(data, bitmap, resources)
        Log.d("getGobangPicture", data)
        return bitmap
    }


    //解析棋子数据并且绘制,若胜利则重置对局
    private fun parserBoardData(data: String, bitmap: Bitmap, resources: Resources) {
        val obj = JSONObject(data)
        val list = obj.getString("str").split(':')
        if (list.size != 4) return
        val boardDataW = list[3].split(',')
        if (boardDataW.size != 15) return
        //循环绘制棋子
        for (i in boardDataW.indices) {
            val boardDataH = boardDataW[i].split('-')
            if (boardDataH.size != 15) return
            for (j in boardDataH.indices) {
                drawChess(i, j, boardDataH[j], bitmap, resources)
            }
        }
        //绘制最后一个落子位置
        val lastPoint=list[0].split(',')
        if(lastPoint.size==2){
            drawChess(lastPoint[0].toInt(), lastPoint[1].toInt(), "last", bitmap, resources)
        }
        if(list[2]!="0"){
            //游戏结束
            ChooseActivity.mChooseActivity.loadGameOver()
            Gobang.mGobang.runOnUiThread {
                Gobang.mGobang.activity_game_gobang_Button_ready.text="准备"
                Gobang.mGobang.activity_game_gobang_TextView_ready.text="未准备"
            }
            OnlineData.isReady="no"
        }

    }

    //绘制棋盘
    private fun getBoardPicture(resources: Resources): Bitmap {
        var bitBoard = BitmapFactory.decodeResource(resources, R.drawable.gobang_board)
        return Bitmap.createBitmap(bitBoard.width, bitBoard.height, Bitmap.Config.ARGB_8888)
    }

    //在棋盘中绘制棋子
    private fun drawChess(xPoint: Int, yPoint: Int, type: String, bitBoard: Bitmap, resources: Resources) {
        var bitChess: Bitmap = when (type) {
            "last" -> BitmapFactory.decodeResource(resources, R.drawable.last_chess)
            "1"-> BitmapFactory.decodeResource(resources, R.drawable.gobang_black)
            "2"-> BitmapFactory.decodeResource(resources, R.drawable.gobang_white)


            else -> return
        }

        bitChess = scaleBitmap(bitChess, bitBoard.width / 14, bitBoard.height / 14)

        //获取绘制坐标
        val xChess = xPoint * bitBoard.width / 15
        val yChess = yPoint * bitBoard.height / 15

        //绘制到图片上
        val canvas: Canvas = Canvas(bitBoard)
        canvas.drawBitmap(bitChess, xChess.toFloat(), yChess.toFloat(), Paint())
        canvas.drawBitmap(bitBoard, 0f, 0f, Paint())
    }





    //缩放图片
    private fun scaleBitmap(origin: Bitmap, newWidth: Int, newHeight: Int): Bitmap {
        if (origin == null) return origin
        val height = origin.height
        val width = origin.width
        val scaleWidth = newWidth.toFloat() / width
        val scaleHeight = newHeight.toFloat() / height
        val matrix = Matrix()
        matrix.postScale(scaleWidth, scaleHeight) // 使用后乘
        val newBM = Bitmap.createBitmap(origin, 0, 0, width, height, matrix, false)
        if (!origin.isRecycled) origin.recycle()
        return newBM
    }

}