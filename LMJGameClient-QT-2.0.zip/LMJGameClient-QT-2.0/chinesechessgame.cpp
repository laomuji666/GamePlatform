#include "chinesechessgame.h"
#include "ui_chinesechessgame.h"

ChineseChessGame::ChineseChessGame(QString username,QString onlineKey,QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ChineseChessGame)
{
    ui->setupUi(this);
    setWindowTitle(username);
    this->parent=parent;
    this->username=username;
    this->onlineKey=onlineKey;
    ((HomeChoose*)parent)->hideWindow();
    setFixedSize(width(),height());
    readyTimer=new QTimer();
    connect(readyTimer,&QTimer::timeout,[&](){getReady();});
    readyTimer->start(1000);
    gameDataTimer=new QTimer();
    connect(gameDataTimer,&QTimer::timeout,[&](){getGameData();});
    gameDataTimer->start(1000);
    replay();
}

ChineseChessGame::~ChineseChessGame()
{
    delete ui;
}
void ChineseChessGame::replay()
{
    for (int i=0;i<boardXSize;i++) {
        for(int j=0;j<boardYSize;j++){
            board[i][j]=0;
        }
    }
    isUp=false;
    allCanChess="";
    lastPoint="";
}

void ChineseChessGame::paintEvent(QPaintEvent *event)
{
    QPainter *paint=new QPainter(this);
    drawBoard(paint);
    drawPieces(paint);

    //绘制提示可落子
    paint->setPen(Qt::yellow);
    paint->setBrush(Qt::yellow);
    if(isUp){
        QStringList pointsList= allCanChess.split(",",QString::SkipEmptyParts);
        for (int i=0;i<pointsList.size();i++) {
            QStringList point=pointsList[i].split("-",QString::SkipEmptyParts);
            if(point.size()==2){
                int x=point[0].toInt();
                int y=point[1].toInt();
                paint->drawRoundRect(piecesSize/2+piecesSize*x,piecesSize/2+piecesSize*y,piecesSize,piecesSize,100,100);
            }
        }
    }

    ui->textEdit->setText(allCanChess);
    paint->end();
}

void ChineseChessGame::closeEvent(QCloseEvent *event)
{
    ((HomeChoose*)parent)->showWindow();
    ((HomeChoose*)parent)->exitHome();
    readyTimer->stop();
    gameDataTimer->stop();
    QWidget::closeEvent(event);
}

void ChineseChessGame::mouseReleaseEvent(QMouseEvent *event){
    //将x,y坐标转换为棋子的位置
    int x=event->x()/piecesSize-1;
    int y=event->y()/piecesSize-1;
    //剩余位置超出棋子一半大小则+1 属于下一个棋子
    if(event->x()%piecesSize>piecesSize/2)x+=1;
    if(event->y()%piecesSize>piecesSize/2)y+=1;
    if(x>8||y>9 ||x<0 ||y<0)return;
    if(isUp==false){
        isUp=true;
        upX=x;
        upY=y;
        getAllCanChess(QString::number(x)+","+QString::number(y));
    }else{
        isUp=false;
        setGameData(QString::number(upX)+","+QString::number(upY)+","+QString::number(x)+","+QString::number(y));
    }

}
void ChineseChessGame::drawBoard(QPainter* paint)
{
    //设置黑色画笔,透明画刷
    paint->setPen(Qt::black);
    paint->setBrush(Qt::transparent);
    //画棋盘
    for (int i=0;i<boardXSize-1;i++) {
        for (int j=0;j<boardYSize-1;j++) {
            paint->drawRect((i+1)*piecesSize,(j+1)*piecesSize,piecesSize,piecesSize);
        }
    }
    //画将帅所在九宫格
    paint->drawLine(4*piecesSize,1*piecesSize,6*piecesSize,3*piecesSize);
    paint->drawLine(6*piecesSize,1*piecesSize,4*piecesSize,3*piecesSize);
    paint->drawLine(4*piecesSize,10*piecesSize,6*piecesSize,8*piecesSize);
    paint->drawLine(6*piecesSize,10*piecesSize,4*piecesSize,8*piecesSize);
}
void ChineseChessGame::drawPieces(QPainter* paint)
{
    paint->setFont(QFont("",18));
    for (int i=0;i<9;i++) {
        for(int j=0;j<10;j++){
            int type=board[i][j];
            paint->setBrush(Qt::yellow);
            if(type>9){
                paint->setPen(Qt::red);
            }else{
                paint->setPen(Qt::black);
            }
            if(type>0){
                paint->drawRoundRect(piecesSize/2+piecesSize*i,piecesSize/2+piecesSize*j,piecesSize,piecesSize,100,100);
                QString str=getPieceStr(type);
                paint->drawText(35+piecesSize*i,piecesSize+piecesSize*j+10,str);
            }
        }
    }
    //绘制lastPoint
    QStringList point =lastPoint.split(",",QString::SkipEmptyParts);
    if(point.size()==4){
        int beginX=point[0].toInt();
        int beginY=point[1].toInt();
        int endX=point[2].toInt();
        int endY=point[3].toInt();
        paint->setBrush(Qt::transparent);
        paint->setPen(Qt::green);
        paint->drawRoundRect(piecesSize/2+piecesSize*beginX,piecesSize/2+piecesSize*beginY,piecesSize,piecesSize,100,100);
        paint->drawRoundRect(piecesSize/2+piecesSize*endX,piecesSize/2+piecesSize*endY,piecesSize,piecesSize,100,100);
    }
}

QString ChineseChessGame::getPieceStr(int type)
{
    if(type>10)type-=10;
    switch (type) {
    case 1:return "车";
    case 2:return "马";
    case 3:return "象";
    case 4:return "士";
    case 5:return "将";
    case 6:return "炮";
    case 7:return "兵";
    default:return "无";
    }
}

void ChineseChessGame::setReady()
{
    if(setReadyManager==nullptr){
        setReadyManager=HttpRequest::postRequest("/ChineseChess/home/ready/set","username="+username+"&onlineKey="+onlineKey+"&isReady="+isReady,this,SLOT(setReadySlot(QNetworkReply*)));
    }

}

void ChineseChessGame::setReadySlot(QNetworkReply*reply)
{
    reply->deleteLater();
    setReadyManager->deleteLater();
    setReadyManager=nullptr;
}

void ChineseChessGame::getReady()
{
    if(getReadyManager==nullptr){
        getReadyManager=HttpRequest::postRequest("/ChineseChess/home/ready/get","username="+username+"&onlineKey="+onlineKey,this,SLOT(getReadySlot(QNetworkReply*)));
    }
}

void ChineseChessGame::getReadySlot(QNetworkReply*reply)
{
    QByteArray bytes=reply->readAll();
    QString id =HttpRequest::getJsonValue(bytes,"id");
    if(id=="0")ui->pushButton->setEnabled(false);
    if(id=="1")ui->pushButton->setEnabled(true);
    QString str = HttpRequest::getJsonValue(bytes,"str");
    ui->label->setText(str);
    reply->deleteLater();
    getReadyManager->deleteLater();
    getReadyManager=nullptr;
}
void ChineseChessGame::getGameData()
{
    if(getGameDataManager==nullptr){
        getGameDataManager=HttpRequest::postRequest("/ChineseChess/home/game/data/get","username="+username+"&onlineKey="+onlineKey,this,SLOT(getGameDataSlot(QNetworkReply*)));
    }
}

void ChineseChessGame::getGameDataSlot(QNetworkReply*reply)
{
    QByteArray bytes=reply->readAll();
    QString id=HttpRequest::getJsonValue(bytes,"id");
    if(id=="0"){
        QString str=HttpRequest::getJsonValue(bytes,"str");
        QStringList strList=str.split(":");
        if(strList.size()==4){
            lastPoint=strList[0];
            if(strList[2]=="无"){
                ui->label_3->setText("轮到:"+strList[1]);
            }else{
                ui->label_3->setText("胜利者:"+strList[2]);
                setGameOver();
            }
            QStringList boardList=strList[3].split(",",QString::SkipEmptyParts);
            for (int i=0;i<boardList.size();i++) {
                QStringList lineList=boardList[i].split("-",QString::SkipEmptyParts);
                for(int j=0;j<lineList.size();j++){
                    board[i][j]=lineList[j].toInt();
                }
            }
        }
    }
    ui->label_2->setText(bytes);
    reply->deleteLater();
    getGameDataManager->deleteLater();
    getGameDataManager=nullptr;
    repaint();
}

void ChineseChessGame::setGameData(QString data)
{
    if(setGameDataManager==nullptr){
        setGameDataManager=HttpRequest::postRequest("/ChineseChess/home/game/data/set","username="+username+"&onlineKey="+onlineKey+"&data="+data,this,SLOT(setGameDataSlot(QNetworkReply*)));
    }
}

void ChineseChessGame::setGameDataSlot(QNetworkReply*reply)
{
    reply->deleteLater();
    setGameDataManager->deleteLater();
    setGameDataManager=nullptr;
    getGameData();
}

void ChineseChessGame::getAllCanChess(QString data)
{
    if(getAllCanChessManager==nullptr){
        getAllCanChessManager=HttpRequest::postRequest("/ChineseChess/home/game/getAllCanChess","username="+username+"&onlineKey="+onlineKey+"&data="+data,this,SLOT(getAllCanChessSlot(QNetworkReply*)));
    }
}

void ChineseChessGame::getAllCanChessSlot(QNetworkReply*reply)
{
    allCanChess=reply->readAll();
    reply->deleteLater();
    getAllCanChessManager->deleteLater();
    getAllCanChessManager=nullptr;
    repaint();
}

void ChineseChessGame::setGameOver()
{
    if(setGameOverManager==nullptr){
        setGameOverManager=HttpRequest::postRequest("/ChineseChess/home/game/over","username="+username+"&onlineKey="+onlineKey,this,SLOT(setGameOverSlot(QNetworkReply*)));
    }

}

void ChineseChessGame::setGameOverSlot(QNetworkReply*reply)
{
    ui->textEdit->append(reply->readAll());
    reply->deleteLater();
    setGameOverManager->deleteLater();
    setGameOverManager=nullptr;
    isReady="no";
}

void ChineseChessGame::on_pushButton_clicked()
{
    if(isReady=="yes"){
        isReady="no";
    }else{
        isReady="yes";
    }
    setReady();
}

void ChineseChessGame::on_pushButton_2_clicked()
{
    setGameData(ui->lineEdit->text());
}

void ChineseChessGame::on_pushButton_3_clicked()
{
    setGameOver();
}
