#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <QMainWindow>
#include <QSettings>
#include <httprequest.h>
#include <QMessageBox>
#include <QPixmap>
#include "lobby.h"
QT_BEGIN_NAMESPACE
namespace Ui { class account; }
QT_END_NAMESPACE

class Account : public QMainWindow
{
    Q_OBJECT

public:
    Account(QWidget *parent = nullptr);
    ~Account();

//请求函数
private:
    void getCodeKey();
    void getCodePicture();
    void registerAccount();
    void loginAccount();
//请求管理器
private:
    QNetworkAccessManager*codeKeyManager=nullptr;
    QNetworkAccessManager*codePictureManager=nullptr;
    QNetworkAccessManager*registerManager=nullptr;
    QNetworkAccessManager*loginManager=nullptr;
//请求槽函数
private slots:
    void getCodeKeySlot(QNetworkReply*);
    void getCodePictureSlot(QNetworkReply*);
    void registerAccountSlot(QNetworkReply*);
    void loginAccountSlot(QNetworkReply*);

private slots:
    void on_checkBox_remember_stateChanged(int arg1);


    void on_lineEdit_code_returnPressed();

protected:
    bool eventFilter(QObject *watched, QEvent *event);

private:
    Ui::account *ui;
    QString configPath="account.ini";
    void writeConfig(); //写账号密码
    void readConfig();  //读账号密码
    QString codeKey;
    QPixmap pixmap;

};
#endif // ACCOUNT_H
