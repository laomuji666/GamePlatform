#include "homechoose.h"
#include "ui_homechoose.h"

HomeChoose::HomeChoose(QString username,QString onlineKey,QString gameUrl,QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::HomeChoose)
{
    ui->setupUi(this);
    this->username=username;
    this->onlineKey=onlineKey;
    this->gameUrl=gameUrl;
    this->parent=parent;
    setWindowTitle("房间选择 - "+gameUrl);
    setFixedSize(width(),height());
    getHomeTimer=new QTimer(this);
    connect(getHomeTimer,&QTimer::timeout,[&](){getHomeData();});
    joinHome("top");
    getHomeData();
}
void HomeChoose::showWindow(){
    getHomeTimer->start(1000);
    show();
}
void HomeChoose::hideWindow(){
    getHomeTimer->stop();
    hide();
}
HomeChoose::~HomeChoose()
{
    delete ui;
}

void HomeChoose::closeEvent(QCloseEvent *event)
{
    if(gameUrl=="/ChineseChess"){
        ((Lobby*)parent)->exitChineseChess();
    }
    if(gameUrl=="/Gobang"){
        ((Lobby*)parent)->exitGobang();
    }
    parent->show();
    getHomeTimer->stop();
    QWidget::closeEvent(event);
}

void HomeChoose::getHomeData()
{
    if(homeDataManager==nullptr){
        homeDataManager=HttpRequest::postRequest(gameUrl+"/home/data","username="+username+"&onlineKey="+onlineKey,this,SLOT(getHomeDataSlot(QNetworkReply*)));
    }
}
void HomeChoose::getHomeDataSlot(QNetworkReply*reply)
{
    QString str=reply->readAll();
    list=str.split("\n",QString::SkipEmptyParts);
    ui->listWidget->clear();
    ui->listWidget->addItems(list);
    if(lastChoose>-1 && lastChoose<list.size()){
        ui->listWidget->setCurrentRow(lastChoose);
    }
    reply->deleteLater();
    homeDataManager->deleteLater();
    homeDataManager=nullptr;
}
void HomeChoose::joinHome(QString position)
{
    if(joinHomeManager==nullptr){
        joinHomeManager=HttpRequest::postRequest(gameUrl+"/home/join","username="+username+"&onlineKey="+onlineKey+"&homeId="+homeId+"&position="+position,this,SLOT(joinHomeSlot(QNetworkReply*)));
    }
}

void HomeChoose::joinHomeSlot(QNetworkReply*reply)
{
    QByteArray str=reply->readAll();
    QString id=HttpRequest::getJsonValue(str,"id");
    reply->deleteLater();
    joinHomeManager->deleteLater();
    joinHomeManager=nullptr;
    if(id!="6")ui->textEdit->append(str); //=6时不需要重连
    if(id=="0"||id=="1"){
        if(gameUrl=="/ChineseChess"){
            ChineseChessGame*game=new ChineseChessGame(username,onlineKey,this);
            game->show();
        }
        if(gameUrl=="/Gobang"){
            GobangGame*gobang=new GobangGame(username,onlineKey,this);
            gobang->show();
        }
    }


}
void HomeChoose::exitHome()
{
    if(exitHomeManager==nullptr){
        exitHomeManager=HttpRequest::postRequest(gameUrl+"/home/exit","username="+username+"&onlineKey="+onlineKey,this,SLOT(exitHomeSlot(QNetworkReply*)));
    }
}

void HomeChoose::exitHomeSlot(QNetworkReply*reply)
{
    QString str=reply->readAll();
    ui->textEdit->append(str);
    reply->deleteLater();
    exitHomeManager->deleteLater();
    exitHomeManager=nullptr;
}

void HomeChoose::on_listWidget_currentRowChanged(int currentRow)
{
    if(currentRow!=-1 && currentRow<list.size()){
           lastChoose=currentRow;
           QByteArray bytes=list[currentRow].toUtf8();
           homeId=HttpRequest::getJsonValue(bytes,"id");
           QString playerTop=HttpRequest::getJsonValue(bytes,"top");
           QString playerBottom=HttpRequest::getJsonValue(bytes,"bottom");
           ui->label->setText("房间号:"+homeId+"\n"+"上方玩家:"+playerTop+"\n"+"下方玩家:"+playerBottom);
    }
}

void HomeChoose::on_pushButton_clicked()
{
    joinHome("top");
}

void HomeChoose::on_pushButton_2_clicked()
{
    joinHome("bottom");
}

void HomeChoose::on_pushButton_3_clicked()
{
    exitHome();
}
