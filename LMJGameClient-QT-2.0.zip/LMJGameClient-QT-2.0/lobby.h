#ifndef LOBBY_H
#define LOBBY_H

#include <QMainWindow>
#include <QTimer>
#include "httprequest.h"
#include "homechoose.h"
namespace Ui {
class Lobby;
}

class Lobby : public QMainWindow
{
    Q_OBJECT

public:
    explicit Lobby(QString username,QString onlineKey,QWidget *parent = nullptr);
    ~Lobby();
//请求函数
public:
    void updateTime();
    void online();
    void offline();
    void joinChineseChess();
    void exitChineseChess();
    void joinGobang();
    void exitGobang();
    void getNotify();
//请求管理器
private:
    QNetworkAccessManager*updateTimeManager=nullptr;
    QNetworkAccessManager*onlineManager=nullptr;
    QNetworkAccessManager*offlineManager=nullptr;
    QNetworkAccessManager*joinChineseChessManager=nullptr;
    QNetworkAccessManager*exitChineseChessManager=nullptr;
    QNetworkAccessManager*joinGobangManager=nullptr;
    QNetworkAccessManager*exitGobangManager=nullptr;
    QNetworkAccessManager*notifyManager=nullptr;
//请求槽函数
private slots:
    void updateTimeSlot(QNetworkReply*);
    void onlineSlot(QNetworkReply*);
    void offlineSlot(QNetworkReply*);
    void joinChineseChessSlot(QNetworkReply*);
    void exitChineseChessSlot(QNetworkReply*);
    void joinGobangSlot(QNetworkReply*);
    void exitGobangSlot(QNetworkReply*);
    void getNotifySlot(QNetworkReply*);

    void on_pushButton_ChineseChess_clicked();
    void on_pushButton_ChineseChess_exit_clicked();
    void on_pushButton_Gobang_clicked();
    void on_pushButton_Gobang_exit_clicked();

private:
    Ui::Lobby *ui;
    QString username,onlineKey;
protected:
    void closeEvent(QCloseEvent *event);
    bool canClose=false;
};

#endif // LOBBY_H
