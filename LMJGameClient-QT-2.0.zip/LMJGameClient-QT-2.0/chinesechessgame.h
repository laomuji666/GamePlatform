#ifndef CHINESECHESSGAME_H
#define CHINESECHESSGAME_H

#include <QMainWindow>
#include <QPainter>
#include <QMouseEvent>
#include <QTimer>
#include "homechoose.h"
#include "httprequest.h"
namespace Ui {
class ChineseChessGame;
}

class ChineseChessGame : public QMainWindow
{
    Q_OBJECT

public:
    explicit ChineseChessGame(QString username,QString onlineKey,QWidget *parent = nullptr);
    ~ChineseChessGame();
private:
    int board[9][10];
    int boardXSize=9;
    int boardYSize=10;
    int piecesSize=50;
    void replay();
    void drawBoard(QPainter* paint);
    void drawPieces(QPainter* paint);
    QString getPieceStr(int type);

    //请求管理器
private:
    QNetworkAccessManager*setReadyManager=nullptr;
    QNetworkAccessManager*getReadyManager=nullptr;
    QNetworkAccessManager*getGameDataManager=nullptr;
    QNetworkAccessManager*setGameDataManager=nullptr;
    QNetworkAccessManager*setGameOverManager=nullptr;
    QNetworkAccessManager*getAllCanChessManager=nullptr;
    //槽函数
private:
    void setReady();
    void getReady();
    void getGameData();
    void setGameData(QString data);
    void setGameOver();
    void getAllCanChess(QString data);
private slots:
    void setReadySlot(QNetworkReply*);
    void getReadySlot(QNetworkReply*);
    void getGameDataSlot(QNetworkReply*);
    void setGameDataSlot(QNetworkReply*);
    void setGameOverSlot(QNetworkReply*);
    void getAllCanChessSlot(QNetworkReply *);

    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();

protected:
    void paintEvent(QPaintEvent *event);
    void closeEvent(QCloseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
private:
    Ui::ChineseChessGame *ui;
    QWidget* parent;
    QString username,onlineKey;
    QString isReady;
    QString whoPosition;
    QTimer*readyTimer;
    QTimer*gameDataTimer;
    bool isUp;  //是否抬起
    int upX,upY;    //抬起坐标
    QString allCanChess; //所有可以下的位置
    QString lastPoint=""; //最后落子坐标
};

#endif // CHINESECHESSGAME_H
