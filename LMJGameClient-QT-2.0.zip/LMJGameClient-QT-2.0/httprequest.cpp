#include "httprequest.h"

QString HttpRequest::getUrl()
{
    return "http://www.laomuji666.com:8686";
}

QNetworkAccessManager* HttpRequest::getRequest(QString url,const QObject *receiver, const char *member){
    url = getUrl() + url;
    QNetworkRequest request;
    request.setUrl(url);
    QNetworkAccessManager*networkManager=new QNetworkAccessManager();
    networkManager->get(request);
    if(member!=nullptr)QObject::connect(networkManager,SIGNAL(finished(QNetworkReply*)),receiver,member);
    return networkManager;
}

QNetworkAccessManager* HttpRequest::postRequest(QString url,QString data,const QObject *receiver, const char *member){
    url = getUrl() + url;
    QNetworkRequest request;
    request.setUrl(url);
    request.setHeader(QNetworkRequest::KnownHeaders::ContentTypeHeader,"application/x-www-form-urlencoded");
    QNetworkAccessManager*networkManager=new QNetworkAccessManager();
    networkManager->post(request,data.toUtf8());
    if(member!=nullptr)QObject::connect(networkManager,SIGNAL(finished(QNetworkReply*)),receiver,member);
    return networkManager;
}

QString HttpRequest::getJsonValue(const QByteArray &jsonByte,QString key){
    QJsonDocument jsdocument=QJsonDocument::fromJson(jsonByte);
    QJsonObject obj=jsdocument.object();
    return obj.value(key).toString();
}
