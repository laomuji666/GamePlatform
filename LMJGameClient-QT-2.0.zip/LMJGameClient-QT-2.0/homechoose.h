#ifndef HOMECHOOSE_H
#define HOMECHOOSE_H

#include <QMainWindow>
#include "lobby.h"
#include "gobanggame.h"
#include "chinesechessgame.h"
namespace Ui {
class HomeChoose;
}

class HomeChoose : public QMainWindow
{
    Q_OBJECT

public:
    explicit HomeChoose(QString username,QString onlineKey,QString gameUrl,QWidget *parent = nullptr);
    ~HomeChoose();
    void showWindow();
    void hideWindow();
//请求函数
public:
    void getHomeData();
    void joinHome(QString position);
    void exitHome();
//请求管理器
private:
    QNetworkAccessManager*homeDataManager=nullptr;
    QNetworkAccessManager*joinHomeManager=nullptr;
    QNetworkAccessManager*exitHomeManager=nullptr;
//请求槽函数
private slots:
    void getHomeDataSlot(QNetworkReply*);
    void joinHomeSlot(QNetworkReply*);
    void exitHomeSlot(QNetworkReply*);




private slots:
    void on_listWidget_currentRowChanged(int currentRow);
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::HomeChoose *ui;
    QString username,onlineKey,gameUrl;
    QWidget *parent;
    QTimer*getHomeTimer;
    QStringList list;
    int lastChoose=-1;
    QString homeId="-1";//-1用于断线重连
protected:
    void closeEvent(QCloseEvent *event);
};

#endif // HOMECHOOSE_H
